//
// Created by supreets51 on 15/10/19.
//

#include "DataItem.h"

DataItem::DataItem(int v): value(v) {}




