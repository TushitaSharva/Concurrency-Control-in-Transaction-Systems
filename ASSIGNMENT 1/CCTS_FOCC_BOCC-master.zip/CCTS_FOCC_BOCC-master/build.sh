#!/usr/bin/env bash
g++ *.cpp *.h -o ccts -std=c++17 -lpthread